from fastapi import APIRouter, UploadFile, File
from app.models import translator, cnc_driver

router = APIRouter()

@router.post("/traducir")
async def traducir_archivo(file: UploadFile = File(...)):
    contenido = await file.read()
    texto = contenido.decode("utf-8")
    braille = translator.traducir_a_braille(texto)
    return {"braille": braille}

@router.post("/imprimir")
async def imprimir(braille: str):
    comandos = translator.braille_a_comandos(braille)
    cnc_driver.enviar_a_cnc(comandos)
    return {"mensaje": "Impresión iniciada"}
