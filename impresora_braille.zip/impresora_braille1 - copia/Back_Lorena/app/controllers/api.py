# Contenido COMPLETO Y CORREGIDO para api.py

from flask import Flask, request, jsonify
from flask_cors import CORS
import fitz
import uuid

from app.models.traduccion_models import (
    texto_a_braille,
    texto_a_unicode,
    generar_gcode_simulacion,
    
    # --- Importaciones correctas ---
    montar_pagina_simple,
    montar_pagina_y_generar_gcode,
    ANCHO_PAGINA_UTIL_MM
)
from app.models.cnc_driver import (
    enviar_gcode_a_impresora,
    # --- ✅ PUNTO 1: Importamos el descubridor ---
    descubrir_impresora_mdns
)

app = Flask(__name__)
CORS(app)

@app.route('/traducir', methods=['POST'])
def traducir():
    
    data = request.form
    ancho_simulado = float(data.get("ancho_pagina_mm", 195.0))
    
    if 'pdf' not in request.files:
        return jsonify({"error": "No se envió archivo PDF"}), 400
    
    archivo = request.files['pdf']
    texto_total = ""
    try:
        with fitz.open(stream=archivo.read(), filetype="pdf") as doc:
            for page in doc:
                texto_total += page.get_text()
    except Exception as e:
        return jsonify({"error": f"Error al leer el PDF: {e}"}), 500
    
    texto_limpio = texto_total.replace(u'\xa0', u' ')
    matrices = texto_a_braille(texto_limpio)
    coords = montar_pagina_simple(matrices, ancho_pagina_mm=ancho_simulado)
    unicode_str = texto_a_unicode(texto_limpio)
    
    return jsonify({
        "unicode": unicode_str,
        "puntos": coords,
        "texto": texto_total
    })

@app.route('/imprimir', methods=['POST'])
def imprimir():
    data = request.get_json() or {}
    texto_original = data.get("texto", "")
    
    request_id = str(uuid.uuid4())[:8]
    print(f"[{request_id}] /imprimir - petición recibida")

    if not texto_original:
        return jsonify({"error": "No se recibió texto para imprimir"}), 400

    texto = texto_original.replace('\\n', ' ').replace('\n', ' ').replace('\r', ' ').replace(u'\xa0', u' ')

    try:
        # --- GENERACIÓN DE G-CODE ---
        print(f"[{request_id}] Texto recibido (limpio): {repr(texto[:120])}")
        matrices = texto_a_braille(texto)
        
        print(f"[{request_id}] Montando página con ancho fijo del backend: {ANCHO_PAGINA_UTIL_MM} mm")
        
        archivo_gcode_real = "impresion.gcode"
        
        # Nueva función maestra
        montar_pagina_y_generar_gcode(matrices, archivo_gcode_real) 
        
        # --- ✅ PUNTO 1: BÚSQUEDA POR HOSTNAME ---
        HOSTNAME_IMPRESORA = "impresorabraille"
        print(f"[{request_id}] Buscando impresora en la red con hostname: {HOSTNAME_IMPRESORA}...")
        
        ip_impresora = descubrir_impresora_mdns(HOSTNAME_IMPRESORA)
        
        if not ip_impresora:
            print(f"[{request_id}] ERROR: No se encontró la impresora.")
            return jsonify({"error": f"No se pudo encontrar la impresora en la red con el hostname: {HOSTNAME_IMPRESORA}"}), 500
        
        print(f"[{request_id}] Impresora encontrada en {ip_impresora}.")
        # --- FIN DE BÚSQUEDA ---

        try:
            print(f"[{request_id}] Enviando G-Code a la impresora en {ip_impresora}...")
            enviar_gcode_a_impresora(ip_impresora, archivo_gcode_real)
            mensaje_final = f"Impresora en {ip_impresora}. G-Code enviado."
            print(f"[{request_id}] Envío completado OK.")
        except Exception as e:
            print(f"[{request_id}] EXCEPCIÓN durante el envío a la impresora: {e}")
            return jsonify({"error": f"Se generó el G-Code, pero falló el envío: {e}"}), 500

        # --- Generar simulación ---
        print(f"[{request_id}] Generando archivo de simulación (impresion_sim.gcode)...")
        coords_simulacion = montar_pagina_simple(matrices, ancho_pagina_mm=ANCHO_PAGINA_UTIL_MM)
        generar_gcode_simulacion(coords_simulacion, "impresion_sim.gcode")

        return jsonify({
            "mensaje": mensaje_final,
            "archivos": [archivo_gcode_real, "impresion_sim.gcode"]
        })
    except Exception as e:
        print(f"[{request_id}] EXCEPCIÓN en la API: {e}")
        return jsonify({"error": str(e)}), 500

@app.errorhandler(Exception)
def handle_exception(e):
    return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(port=5000, debug=True, use_reloader=True)