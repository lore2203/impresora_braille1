# Contenido COMPLETO Y CORREGIDO para app/models/traduccion_models.py

from typing import List, Tuple, Any
import re # Para limpiar el texto

# === Parámetros (del apartado "Parámetros del Braile") ===
DOT_TO_DOT_HORIZONTAL_MM = 1.5
DOT_TO_DOT_VERTICAL_MM   = 1.5
INTER_CELL_SPACE_MM = 0.5
INTER_CHAR_SPACE_MM = 3.0 # (No se usa activamente si ANCHO_CELDA_MM está bien)
INTER_WORD_SPACE_MM = 6.0
MARGIN_LEFT_MM = 2.0
MARGIN_TOP_MM = 2.0

# --- ✅ ¡TU VARIABLE MANUAL! ---
# Como pediste, aquí puedes ajustar el ancho útil de la página.
ANCHO_PAGINA_UTIL_MM = 105.0 

# --- ✅ TU SECUENCIA DE SALTO DE LÍNEA ---
# Como pediste, esta es la secuencia de G-Code que se insertará
# cada vez que el "word wrap" detecte un salto de línea.
GCODE_SALTO_DE_LINEA = [
    "; --- SALTO DE LINEA AUTOMATICO ---",
    "$HX",  # 1. Homing en X (el driver lo hará robusto)
    "G91",  # 2. Moverse en relativo
    "G0 Y10 F3000", # 3. Bajar 10mm en Y (tus 10mm)
    "G90",  # 4. Volver a modo absoluto
    f"G0 X{MARGIN_LEFT_MM:.2f}" # 5. Mover al margen izquierdo
]
# --- ✅ Altura de línea (debe coincidir con tu G0 Y10) ---
LINE_HEIGHT_MM = 10.0


# === Mapa de cada carácter a su matriz 3 filas × 2 columnas ===
CHAR_TO_MATRIX = {
    # No más '\n', ya que no viene del PDF
    'a': [[1,0],[0,0],[0,0]], 'b': [[1,0],[1,0],[0,0]], 'c': [[1,1],[0,0],[0,0]],
    'd': [[1,1],[0,1],[0,0]], 'e': [[1,0],[0,1],[0,0]], 'f': [[1,1],[1,0],[0,0]],
    'g': [[1,1],[1,1],[0,0]], 'h': [[1,0],[1,1],[0,0]], 'i': [[0,1],[1,0],[0,0]],
    'j': [[0,1],[1,1],[0,0]], 'k': [[1,0],[0,0],[1,0]], 'l': [[1,0],[1,0],[1,0]],
    'm': [[1,1],[0,0],[1,0]], 'n': [[1,1],[0,1],[1,0]], 'o': [[1,0],[0,1],[1,0]],
    'p': [[1,1],[1,0],[1,0]], 'q': [[1,1],[1,1],[1,0]], 'r': [[1,0],[1,1],[1,0]],
    's': [[0,1],[1,0],[1,0]], 't': [[0,1],[1,1],[1,0]], 'u': [[1,0],[0,0],[1,1]],
    'v': [[1,0],[1,0],[1,1]], 'w': [[0,1],[1,1],[0,1]], 'x': [[1,1],[0,0],[1,1]],
    'y': [[1,1],[0,1],[1,1]], 'z': [[1,0],[0,1],[1,1]], 'á': [[1,0],[1,1],[1,1]],
    'é': [[0,1],[1,0],[1,1]], 'í': [[0,1],[0,0],[1,0]], 'ó': [[0,1],[0,0],[1,1]],
    'ú': [[0,1],[1,1],[1,1]], 'ñ': [[1,1],[1,1],[0,1]], 'ü': [[1,0],[1,1],[0,1]],
    'CAP': [[0,1],[0,0],[0,1]], 'NUM': [[0,1],[0,1],[1,1]], '1': [[1,0],[0,0],[0,0]],
    '2': [[1,0],[1,0],[0,0]], '3': [[1,1],[0,0],[0,0]], '4': [[1,1],[0,1],[0,0]],
    '5': [[1,0],[0,1],[0,0]], '6': [[1,1],[1,0],[0,0]], '7': [[1,1],[1,1],[0,0]],
    '8': [[1,0],[1,1],[0,0]], '9': [[0,1],[1,0],[0,0]], '0': [[0,1],[1,1],[0,0]],
    ' ': [[0,0],[0,0],[0,0]], ',': [[0,0],[1,0],[0,0]], ';': [[0,0],[1,0],[1,0]],
    ':': [[0,0],[1,1],[0,0]], '.': [[0,0],[0,0],[1,0]], '!': [[0,0],[1,1],[1,0]],
    '?': [[0,0],[1,0],[0,1]], '¿': [[0,0],[1,0],[0,1]], '¡': [[0,0],[1,1],[1,0]],
    '"': [[0,0],[1,0],[1,1]], '(': [[1,0],[1,0],[0,1]], ')': [[0,1],[0,1],[1,0]],
}

# --- Ancho de celda (CORREGIDO) ---
ANCHO_CELDA_MM = DOT_TO_DOT_HORIZONTAL_MM + INTER_CHAR_SPACE_MM

# === Mapeo Unicode (No cambia) ===
MATRIX_TO_UNICODE: dict = {}
for ch, mat in CHAR_TO_MATRIX.items():
    if isinstance(mat, str): continue
    code = 0
    if mat[0][0]: code |= 1
    if mat[1][0]: code |= 2
    if mat[2][0]: code |= 4
    if mat[0][1]: code |= 8
    if mat[1][1]: code |= 16
    if mat[2][1]: code |= 32
    MATRIX_TO_UNICODE[tuple(tuple(row) for row in mat)] = chr(0x2800 + code)

# === Traductor de texto a matrices (Simplificado) ===
def texto_a_braille(texto: str) -> List[Any]:
    mats: List[Any] = []
    modo_num = False
    
    texto_limpio = re.sub(r'[\n\r\t\xa0]+', ' ', texto) 
    
    for ch in texto_limpio:
        ch_lower = ch.lower()
        if ch.isupper() and ch_lower in CHAR_TO_MATRIX:
            mats.append(CHAR_TO_MATRIX['CAP'])
            ch = ch_lower
            modo_num = False
            
        if ch.isdigit():
            if not modo_num:
                mats.append(CHAR_TO_MATRIX['NUM'])
                modo_num = True
            mats.append(CHAR_TO_MATRIX[ch])
            continue
            
        if modo_num and not ch.isdigit():
             modo_num = False
        
        mats.append(CHAR_TO_MATRIX.get(ch, CHAR_TO_MATRIX[' ']))
    return mats

# === Lógica de Word Wrap (NUEVA Y CORRECTA) ===

def _calcular_ancho_palabra(matrices_palabra: List[List[List[int]]]) -> float:
    if not matrices_palabra:
        return 0.0
    return len(matrices_palabra) * ANCHO_CELDA_MM

def montar_pagina_y_generar_gcode(matrices: List[Any], archivo_salida="impresion.gcode"):
    print("LOG: Iniciando generación de G-Code con 'word wrap'...")
    gcode = []
    gcode.append("; --- INICIO DE ARCHIVO G-CODE BRAILLE ---")
    gcode.append("G21")
    gcode.append("G90")
    gcode.append("$X")
    #gcode.append("$HX")
    #gcode.append("$HY")
    gcode.append("G0 F9000") # Velocidad de viaje alta F9000

    x_cursor = MARGIN_LEFT_MM
    y_cursor = MARGIN_TOP_MM
    
    print(f"LOG: Cursor inicial en X={x_cursor}, Y={y_cursor}. Ancho útil={ANCHO_PAGINA_UTIL_MM} mm")
    
    palabras_y_espacios = []
    palabra_actual_mats = []
    mat_espacio = CHAR_TO_MATRIX[' ']

    for mat in matrices:
        if mat == mat_espacio:
            if palabra_actual_mats:
                ancho = _calcular_ancho_palabra(palabra_actual_mats)
                palabras_y_espacios.append( ("PALABRA", palabra_actual_mats, ancho) )
                palabra_actual_mats = []
            
            palabras_y_espacios.append( ("ESPACIO", [mat_espacio], INTER_WORD_SPACE_MM) )
        else:
            palabra_actual_mats.append(mat)

    if palabra_actual_mats:
       ancho = _calcular_ancho_palabra(palabra_actual_mats)
       palabras_y_espacios.append( ("PALABRA", palabra_actual_mats, ancho) )

    print(f"LOG: Texto agrupado en {len(palabras_y_espacios)} 'palabras' y 'espacios'.")
    
    current_line_num = 1
    
    for (tipo, mats, ancho) in palabras_y_espacios:
        if (x_cursor + ancho) > (ANCHO_PAGINA_UTIL_MM - MARGIN_LEFT_MM):
            print(f"LOG: Palabra/espacio (ancho {ancho:.2f}mm) no cabe en la línea {current_line_num} (cursor en {x_cursor:.2f}mm).")
            print("LOG: ---> ¡Insertando GCODE_SALTO_DE_LINEA!")
            
            if tipo == "ESPACIO":
                gcode.extend(GCODE_SALTO_DE_LINEA)
                y_cursor += LINE_HEIGHT_MM
                x_cursor = MARGIN_LEFT_MM
                current_line_num += 1
                print(f"LOG: Salto por ESPACIO. Iniciando línea {current_line_num}. Cursor en X={x_cursor}, Y={y_cursor}")
                continue
            
            gcode.extend(GCODE_SALTO_DE_LINEA)
            y_cursor += LINE_HEIGHT_MM
            x_cursor = MARGIN_LEFT_MM
            current_line_num += 1
            print(f"LOG: Salto por PALABRA. Iniciando línea {current_line_num}. Cursor en X={x_cursor}, Y={y_cursor}")
        
        if tipo == "ESPACIO":
            x_cursor += ancho
            continue

        if tipo == "PALABRA":
            for mat in mats:
                for r in range(3):
                    for c in range(2):
                        if mat[r][c]:
                            x_punto = x_cursor + c * DOT_TO_DOT_HORIZONTAL_MM
                            y_punto = y_cursor + r * DOT_TO_DOT_VERTICAL_MM
                            gcode.append(f"G0 X{x_punto:.2f} Y{y_punto:.2f}")
                            gcode.append(";PUNCH")
                            
                x_cursor += ANCHO_CELDA_MM
            
    # --- Fin del proceso ---
    print(f"LOG: Generación de G-Code finalizada. Total {current_line_num} líneas.")
    gcode.append("; --- FIN DE IMPRESION ---")
    
    # <--- CAMBIO CLAVE: AÑADIR SECUENCIA DE HOMING AL FINAL DEL TRABAJO
    gcode.append("; --- SECUENCIA FINAL: VOLVER A HOME ---")
    gcode.append("$HX")
    gcode.append("$HY")
    
    gcode.append("; --- FIN DEL ARCHIVO ---")

    with open(archivo_salida, "w") as f:
        f.write("\n".join(gcode))

    print(f"✅ Archivo G-Code final guardado en: {archivo_salida}")


# === Funciones Antiguas (que usa /traducir para simulación) ===
# (No se han modificado, se omiten por brevedad en la explicación pero están en el código)
def montar_pagina_simple(matrices: List[Any], ancho_pagina_mm: float) -> List[Tuple[float, float]]:
    coords = []
    x, y = MARGIN_LEFT_MM, MARGIN_TOP_MM
    mat_espacio = CHAR_TO_MATRIX[' ']
    palabra_actual_coords = []
    ancho_palabra_actual = 0.0
    for mat in matrices:
        if isinstance(mat, str): continue
        ancho_letra = ANCHO_CELDA_MM
        if mat == mat_espacio:
            if (x + ancho_palabra_actual) > ancho_pagina_mm:
                x = MARGIN_LEFT_MM
                y += LINE_HEIGHT_MM
                coords_movidos = [(cx - min(c[0] for c in palabra_actual_coords) + MARGIN_LEFT_MM, cy + LINE_HEIGHT_MM) for cx, cy in palabra_actual_coords]
                coords.extend(coords_movidos)
            else:
                coords.extend(palabra_actual_coords)
            x += ancho_palabra_actual + INTER_WORD_SPACE_MM
            palabra_actual_coords = []
            ancho_palabra_actual = 0.0
        else:
            for r in range(3):
                for c in range(2):
                    if mat[r][c]:
                        palabra_actual_coords.append((x + c*DOT_TO_DOT_HORIZONTAL_MM, y + r*DOT_TO_DOT_VERTICAL_MM))
            x += ancho_letra
            ancho_palabra_actual += ancho_letra
    if (x + ancho_palabra_actual) > ancho_pagina_mm and coords:
        x = MARGIN_LEFT_MM
        y += LINE_HEIGHT_MM
        coords_movidos = [(cx - min(c[0] for c in palabra_actual_coords) + MARGIN_LEFT_MM, cy + LINE_HEIGHT_MM) for cx, cy in palabra_actual_coords]
        coords.extend(coords_movidos)
    else:
        coords.extend(palabra_actual_coords)
    return coords

def texto_a_unicode(texto: str) -> str:
    texto_limpio = re.sub(r'[\n\r\t\xa0]+', ' ', texto) 
    resultado: List[str] = []
    mats = texto_a_braille(texto_limpio)
    for mat in mats:
        if isinstance(mat, str): continue
        key = tuple(tuple(row) for row in mat)
        unicode_char = MATRIX_TO_UNICODE.get(key, '⍰')
        resultado.append(unicode_char)
    return ''.join(resultado)

def generar_gcode_simulacion(coords_list: List[Any], archivo_salida="impresion_sim.gcode"):
    gcode = []
    gcode.append("G21")
    gcode.append("G90")
    gcode.append("G0 Z5.00")
    coords = coords_list
    if not coords or not isinstance(coords[0], tuple):
        print(f"WARN: generar_gcode_simulacion recibió datos extraños: {coords[:5]}")
        coords = []
    for (x, y) in coords:
        gcode.append(f"G0 X{x:.2f} Y{y:.2f}")
        gcode.append("G1 Z-1.00 F300")
        gcode.append("G0 Z5.00")
    gcode.append("; --- Fin del archivo ---")
    with open(archivo_salida, "w") as f:
        f.write("\n".join(gcode))
    print(f"✅ Archivo de simulación guardado en: {archivo_salida}")
