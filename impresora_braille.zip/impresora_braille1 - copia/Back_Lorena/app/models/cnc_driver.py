# Contenido COMPLETO Y CORREGIDO para app/models/cnc_driver.py

import socket
import time
from zeroconf import Zeroconf

# ======================================================
# 🔎 Descubrimiento mDNS (No cambia)
# ======================================================
def descubrir_impresora_mdns(hostname: str = "impresorabraille", timeout: int = 5) -> str | None:
    print(f"🔎 Buscando impresora con el hostname: {hostname}...")
    zeroconf = Zeroconf()
    service_type = "_http._tcp.local."
    service_name = f"{hostname}.{service_type}"
    info = zeroconf.get_service_info(service_type, name=service_name, timeout=timeout * 1000)
    zeroconf.close()

    if info and info.addresses:
        ip_address = socket.inet_ntoa(info.addresses[0])
        print(f"✅ ¡Impresora encontrada en {ip_address}!")
        return ip_address
    else:
        print(f"❌ ERROR: No se encontró la impresora con hostname '{hostname}' en la red.")
        return None

# ======================================================
# ⚙ Envío del G-Code (Driver "Tonto" pero Robusto)
# ======================================================
def enviar_gcode_a_impresora(host: str, archivo_gcode: str, puerto: int = 23):
    print(f"🔌 Conectando a la impresora en {host}:{puerto}...")

    TIEMPO_PUNZONADO_MS = 100
    TIEMPO_RETRACT_MS = 60
    TIEMPO_ASENTAMIENTO_MS = 1500 # Aumentamos a 1.5s por seguridad
    CMD_SOLENOIDE_ARRIBA = b"M3 S1\n"
    CMD_SOLENOIDE_ABAJO  = b"M5 S1\n"
    CMD_DESBLOQUEO = b"$X\n"
    CMD_ABS_COORDS = b"G90\n"

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(20)
        try:
            s.connect((host, puerto))
        except Exception:
            raise ConnectionError(f"No se pudo conectar a {host}:{puerto}")

        def read_until(text_bytes: bytes, timeout=15):
            data = b''
            start = time.time()
            while time.time() - start < timeout:
                try:
                    s.settimeout(0.1)
                    chunk = s.recv(512)
                    if not chunk: raise ConnectionError("Impresora desconectada.")
                    data += chunk
                    if text_bytes in data: return data
                except socket.timeout: continue
            
            error_msg = data.decode('ascii', 'ignore').strip()
            print(f"❌ ERROR: Timeout esperando '{text_bytes.decode()}'")
            print(f"     -> Últimos datos recibidos: {error_msg}")
            raise ConnectionError(f"Timeout de GRBL.")

        # Esta función ya no se usa en el arranque, solo en tu bucle principal
        # (La hemos modificado para que sea segura)
        def _execute_homing_cycle(axis_command: str):
            """Sube el punzón, hace homing, DESBLOQUEA, y lo mantiene arriba."""
            print(f"⚙  Iniciando ciclo de Homing seguro para '{axis_command}'...")
           
            # 1. Subir punzón (M3)
            print("    -> 1. Subiendo punzón (M3 S1) para evitar arrastre...")
            s.sendall(CMD_SOLENOIDE_ARRIBA); read_until(b"ok", 5)
            print(f"    -> 2. Esperando {TIEMPO_ASENTAMIENTO_MS}ms...")
            time.sleep(TIEMPO_ASENTAMIENTO_MS / 1000.0)

            # 2. Ejecutar homing (se bloqueará con error:9)
            print(f"    -> 3. Ejecutando comando de Homing '{axis_command}'...")
            s.sendall(f"{axis_command}\n".encode("ascii"))
            read_until(b"ok", timeout=60)
            print(f"    -> 4. Homing '{axis_command}' completado.")

            # 3. Desbloquear (para error:9)
            print("    -> 5. Desbloqueando máquina ($X)...")
            s.sendall(CMD_DESBLOQUEO); read_until(b"ok")

            # 4. Establecer absoluto (para ALARM:2)
            print("    -> 6. Estableciendo modo absoluto (G90)...")
            s.sendall(CMD_ABS_COORDS); read_until(b"ok")

            # 5. Re-confirmar que el punzón sigue arriba
            print("    -> 7. Re-asegurando punzón ARRIBA (M3 S1).")
            s.sendall(CMD_SOLENOIDE_ARRIBA); read_until(b"ok", 5)
            print("    -> 8. Ciclo de Homing seguro finalizado.")


        # --- Secuencia de inicio (TOTALMENTE REESCRITA) ---
        read_until(b"Grbl", timeout=10)
        print("✅ Conexión con GRBL establecida.")
       
        # 1. DESBLOQUEAR PRIMERO
        print("⚙ Enviando $X inicial para desbloquear (saliendo de alarma)...")
        s.sendall(CMD_DESBLOQUEO); read_until(b"ok")
        print("👍 Máquina desbloqueada.")
        
        # 2. HACER HOMING (ANTES de intentar subir el punzón)
        print("--- INICIANDO SECUENCIA DE PREPARACIÓN (HOMING) ---")
        
        print("🏠 Realizando Homing en Eje X ($HX)...")
        s.sendall(b"$HX\n"); read_until(b"ok", timeout=60)
        print("👍 Homing X completo. (Máquina bloqueada con error:9)")
        
        print("🔓 Desbloqueando de $HX...")
        s.sendall(CMD_DESBLOQUEO); read_until(b"ok")

        print("🏠 Realizando Homing en Eje Y ($HY)...")
        s.sendall(b"$HY\n"); read_until(b"ok", timeout=60)
        print("👍 Homing Y completo. (Máquina bloqueada con error:9)")
        
        print("🔓 Desbloqueando de $HY...")
        s.sendall(CMD_DESBLOQUEO); read_until(b"ok")

        # 3. ESTABLECER MODO ABSOLUTO (para evitar ALARM:2)
        print("📏 Estableciendo modo absoluto (G90)...")
        s.sendall(CMD_ABS_COORDS); read_until(b"ok")
        
        # 4. AHORA SÍ, SUBIR EL PUNZÓN
        print("🚀 Subiendo punzón (M3 S1) DESPUÉS de homing y desbloqueo...")
        s.sendall(CMD_SOLENOIDE_ARRIBA); read_until(b"ok")
        
        print(f"   -> Esperando {TIEMPO_ASENTAMIENTO_MS}ms para que el punzón suba...")
        time.sleep(TIEMPO_ASENTAMIENTO_MS / 1000.0)

        print("--- PREPARACIÓN FINALIZADA. Máquina en origen con punzón arriba. ---")
        
        with open(archivo_gcode, "r") as f:
            lineas = [line.strip() for line in f if line.strip()]
       
        # --- Bucle principal (Modificado para ser seguro) ---
        for comando in lineas:
            try:
                if comando.upper() == "M3 S1":
                    s.sendall(CMD_SOLENOIDE_ARRIBA); read_until(b"ok")
                    time.sleep(TIEMPO_ASENTAMIENTO_MS / 1000.0)
                    continue
                
                elif comando.upper() == "M5 S1":
                    s.sendall(CMD_SOLENOIDE_ABAJO); read_until(b"ok")
                    continue
                
                # Manejo de Homing SEGURO (para saltos de línea)
                elif comando.upper().startswith('$H'):
                     print(f"⚙  Detectado Homing en G-Code: {comando}. Ejecutando ciclo seguro...")
                     # Usamos la función segura que definimos arriba
                     _execute_homing_cycle(comando)
                     print("   -> Salto de línea seguro completado.")
                     continue

                elif comando == ";PUNCH":
                    s.sendall(CMD_SOLENOIDE_ABAJO); read_until(b"ok")
                    time.sleep(TIEMPO_PUNZONADO_MS / 1000.0)
                    s.sendall(CMD_SOLENOIDE_ARRIBA); read_until(b"ok")
                    time.sleep(TIEMPO_RETRACT_MS / 1000.0)
                    continue
                
                elif not comando.startswith(";"):
                    s.sendall((comando + "\n").encode("ascii"))
                    read_until(b"ok")
                
                elif comando.startswith(";"):
                    continue

            except Exception as e:
                print(f"💥 EXCEPCIÓN fatal durante el envío del comando '{comando}': {e}")
                try: s.sendall(CMD_SOLENOIDE_ABAJO)
                except: pass
                raise

        # --- SECUENCIA DE FINALIZACIÓN (Corregida para ser segura) ---
        try:
            print("✅ Impresión finalizada. Iniciando secuencia de fin de trabajo.")
            
            print("🏠 Volviendo a casa ($H)...")
            s.sendall(b"$H\n"); read_until(b"ok", timeout=120)
            print("🔓 Desbloqueando...")
            s.sendall(CMD_DESBLOQUEO); read_until(b"ok")
            print("📏 Modo absoluto...")
            s.sendall(CMD_ABS_COORDS); read_until(b"ok")
            print("🚀 Subiendo punzón...")
            s.sendall(CMD_SOLENOIDE_ARRIBA); read_until(b"ok")
            time.sleep(TIEMPO_ASENTAMIENTO_MS / 1000.0)
            
            print("👍 Máquina en origen con punzón ARRIBA.")
            print(f"⏳ Manteniendo por 5 segundos para retirar la hoja...")
            time.sleep(5)
            
            print("⏰ Tiempo de espera finalizado. Bajando punzón a posición de reposo (M5 S1).")
            s.sendall(CMD_SOLENOIDE_ABAJO)
            read_until(b"ok", timeout=5)
            print("💤 Punzón en reposo. Trabajo completado.")

        except Exception as e:
            print(f"⚠ Advertencia: Ocurrió un error durante la secuencia de finalización: {e}")

        print("🎉 ¡Trabajo completado! Conexión cerrada.")
