from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
import os
import shutil
from Back_Lorena.app.models.traduccion_models import traducir_pdf_a_braille

app = FastAPI()

# Configurar CORS para permitir peticiones desde el frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # ⚠️ En producción, cambia esto por el dominio de tu frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Directorio donde se guardan temporalmente los archivos
UPLOAD_DIR = "uploaded_files"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.post("/traducir")
async def traducir_pdf(file: UploadFile = File(...)):
    try:
        # Guardar el archivo PDF temporalmente
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # Procesar el archivo y obtener coordenadas Braille
        coordenadas = traducir_pdf_a_braille(file_path)
        return {"coordenadas": coordenadas}

    except Exception as e:
        return {"error": f"Error al procesar el PDF: {str(e)}"}
