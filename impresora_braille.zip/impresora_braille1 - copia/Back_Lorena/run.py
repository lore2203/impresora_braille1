# run.py
from app.controllers.api import app

if __name__ == '__main__':
    # Usar host='0.0.0.0' hace que el servidor sea accesible
    # desde otros dispositivos en tu misma red WiFi.
    # Es ideal para que tu frontend (Electron) pueda conectarse.
    print("🚀 Servidor de la impresora Braille iniciado.")
    
    print("✅ Accede desde el navegador o tu app en http://127.0.0.1:5000")
    app.run(host='0.0.0.0', port=5000, debug=True, use_reloader=False)