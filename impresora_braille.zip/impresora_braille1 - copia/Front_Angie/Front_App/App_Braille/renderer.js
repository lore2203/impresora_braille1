// Variable global para guardar el texto original del PDF
let textoOriginal = "";

// Botón para abrir el selector de archivo 
document.getElementById("uploadButton").addEventListener("click", () => {
  document.getElementById("pdfFile").click();
});

// Mostrar nombre del archivo cargado
document.getElementById("pdfFile").addEventListener("change", (event) => {
  const file = event.target.files[0];
  if (file) {
    document.getElementById("fileName").textContent = file.name;
  } else {
    document.getElementById("fileName").textContent = "No hay ningún archivo seleccionado";
  }
});

// Traducir
document.getElementById("translateButton").addEventListener("click", () => {
  const file = document.getElementById("pdfFile").files[0];
  if (!file) {
    alert("Primero debes seleccionar un archivo PDF.");
    return;
  }

  showModal(async () => {
    const formData = new FormData();
    formData.append("pdf", file);

    console.log("Enviando archivo al backend...");

    try {
      const response = await fetch("http://localhost:5000/traducir", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error("Error del servidor:", errorText);
        throw new Error("Error en el servidor.");
      }

      const data = await response.json();
      console.log("Respuesta del backend:", data);

      // Guardamos el texto plano original en la variable global
      textoOriginal = data.texto || "";

      // Mostrar Braille Unicode en el textarea
      document.getElementById("brailleText").value = data.unicode;

      Swal.fire("Traducción completada", "", "success");
    } catch (error) {
      console.error(error);
      Swal.fire("Error al traducir el PDF");
    }
  });
});

// Imprimir
document.getElementById("printButton").addEventListener("click", async () => {
  if (!textoOriginal) {
    alert("Primero debes traducir un archivo antes de imprimir.");
    return;
  }

  showModal(async () => {
    try {
      console.log("Enviando a imprimir...");
      const response = await fetch("http://localhost:5000/imprimir", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ texto: textoOriginal }) 
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error("Error:", errorText);
        throw new Error("Error en el servidor.");
      }

      const data = await response.json();
      console.log("Respuesta:", data);
      Swal.fire("Impresión lista", data.mensaje, "success");
    } catch (error) {
      console.error(error);
      Swal.fire("Error al generar el G-Code");
    }
  });
});

// Función para mostrar la ventana modal
function showModal(onConfirm) {
  const modal = document.getElementById("customModal");
  modal.style.display = "block";

  const yesBtn = document.getElementById("confirmYes");
  const noBtn = document.getElementById("confirmNo");

  yesBtn.onclick = () => {
    modal.style.display = "none";
    onConfirm();
  };

  noBtn.onclick = () => {
    modal.style.display = "none";
  };
}
